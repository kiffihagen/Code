package Models;

public interface Allele {
	
	abstract void mutate();

}
