import java.io.IOException;


public class MainMenu {
	

	public static void main(String[] args) throws IOException {
		Menu m = new Menu();
		m.run();

	}

}
