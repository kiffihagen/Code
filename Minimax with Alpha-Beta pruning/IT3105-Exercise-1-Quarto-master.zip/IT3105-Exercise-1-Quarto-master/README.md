IT3105-Exercise-1-Quarto
========================
