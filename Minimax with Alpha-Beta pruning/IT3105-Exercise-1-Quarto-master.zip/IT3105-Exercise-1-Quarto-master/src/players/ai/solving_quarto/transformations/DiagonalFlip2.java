package players.ai.solving_quarto.transformations;

import board.BoardState;

public class DiagonalFlip2 extends Transformation {

	@Override
	public BoardState transform(BoardState s) {
		// TODO Auto-generated method stub
		return s;
	}

}
