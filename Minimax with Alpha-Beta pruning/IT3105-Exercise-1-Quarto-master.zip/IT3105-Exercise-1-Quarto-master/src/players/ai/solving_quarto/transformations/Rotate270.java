package players.ai.solving_quarto.transformations;

import board.BoardState;

public class Rotate270  extends Transformation{

	@Override
	public BoardState transform(BoardState s) {
		// TODO Auto-generated method stub
		return null;
	}

}
