package players.ai.minmax.evaluation;

import board.BoardState;

public class ConstantEval extends BaseEvaluator {

	@Override
	public int evaluate(BoardState board, boolean max) {

			return 0;
	
	}


}
